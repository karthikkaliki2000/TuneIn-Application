package com.example.TuneIn;

public interface Song {

    /** This function returns the song name. **/
    String getSongName();

    /** This function sets the name of the song (name attribute). **/
    void setName(String name);

}

